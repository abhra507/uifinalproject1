import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-edit-meeting',
  templateUrl: './edit-meeting.component.html',
  styleUrls: ['./edit-meeting.component.css']
})
export class EditMeetingComponent implements OnInit {

  meetingtopic:string='';
  meetingid:number=0;
  numberofpeople:number=0;
  starttime:string='';
  message:string='';
  constructor(private http:HttpClient,private route:ActivatedRoute,private router:Router) { }


  ngOnInit(): void {
    this.route.paramMap.subscribe(params=>{
      const idParam=params.get('meetingid');
           if(idParam!==null){
        this.meetingid=+idParam;
        this.fetchProduct();
      }
      else{
        console.error("meetingid is missing  or null");
      }


    })
  }


fetchProduct(){
  this.http.get('http://localhost:3000/getMeeting/'+this.meetingid)
      .subscribe((response:any)=>
    {
      const meeting=response[0];
      this.meetingtopic=meeting.meetingtopic;
      this.numberofpeople=meeting.numberofpeople;
      console.log(this.numberofpeople)
      this.starttime=meeting.starttime;
          },
    (error)=>{console.error('Error fetching the meeting',error);}
  );
}


UpdateMeeting(){
    const meeting={
      meetingid:this.meetingid,
      meetingtopic:this.meetingtopic,      
      numberofpeople:this.numberofpeople,
      starttime:this.starttime
    };


    this.http.put('http://localhost:3000/updateMeeting',meeting)
    .subscribe((response:any)=>
    {this.message=response.message;this.router.navigate(['/view'])},
    (error)=>{console.error('Error updating the meeting',error);}
  );


  }

}
