import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-client',
  templateUrl: './add-client.component.html',
  styleUrls: ['./add-client.component.css']
})
export class AddClientComponent  {
  name1:string='';
  email:string='';
  address:string='';
  password1:string='';
  repeatpassword:string='';
  message:string='';
  constructor(private http:HttpClient) { }


  ngOnInit(): void {
  }
  addClient(){
    const client={
      name1:this.name1,
      email:this.email,
      address:this.address,
      password1:this.password1,
      repeatpassword:this.repeatpassword
    };


    this.http.post('http://localhost:3000/addClient',client)
    .subscribe((response:any)=>
    {this.message=response.message},
    (error)=>{console.error('Error adding the client',error);}
  );
}


}
