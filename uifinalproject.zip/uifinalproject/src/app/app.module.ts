import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddClientComponent } from './add-client/add-client.component';
import { AddMeetingComponent } from './add-meeting/add-meeting.component';
import { EditMeetingComponent } from './edit-meeting/edit-meeting.component';
import { ViewMeetingComponent } from './view-meeting/view-meeting.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ViewClientComponent } from './view-client/view-client.component';
const routes:Routes=[
{path:'',redirectTo:'/view1',pathMatch:'full'},
{path:'add',component:AddClientComponent},
{path:'add1',component:AddMeetingComponent},
{path:'edit/:meetingid',component:EditMeetingComponent},
{path:'view',component:ViewMeetingComponent},
{path:'view1',component:ViewClientComponent}
]


@NgModule({
  declarations: [
    AppComponent,
    AddClientComponent,
    AddMeetingComponent,
    EditMeetingComponent,
    ViewMeetingComponent,
    ViewClientComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(routes)

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
