import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-meeting',
  templateUrl: './add-meeting.component.html',
  styleUrls: ['./add-meeting.component.css']
})
export class AddMeetingComponent {
  meetingtopic:string='';
  meetingid:number=0;
  numberofpeople:number=0;
  starttime:string='';
  message:string='';
  constructor(private http:HttpClient) { }


  ngOnInit(): void {
  }
  addMeeting(){
    const meeting={
      meetingtopic:this.meetingtopic,
      meetingid:this.meetingid,
      numberofpeople:this.numberofpeople,
      starttime:this.starttime 
    };


    this.http.post('http://localhost:3000/addMeeting',meeting)
    .subscribe((response:any)=>
    {this.message=response.message},
    (error)=>{console.error('Error adding the meeting',error);}
  );

}
}
