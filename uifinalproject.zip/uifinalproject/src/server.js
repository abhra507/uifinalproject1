//dependencies
const express=require('express')
const bodyParser=require('body-parser')
const cors=require('cors')
const mysql=require('mysql')

//define the express operation
const app=express();
const port=3000;


//defining the cors -cross origin by reciving the data in json format
app.use(cors());
app.use(bodyParser.json())

//establish the connection with the dB
const db=mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'root',
    database:'db2'    
    });
        
    //verifying whether db is connected or not
    db.connect(err=>{
    if(err){
        console.error('connection is not established with the dB',err);
    }
    else{
        console.log('Connected to db')
    }
    
    
    });
    
    app.listen(port,()=>{console.log('server port estbalished on 3000')})

    //to get all the meetings
 app.get('/getMeetings',(req,res)=>{
    const sql='select * from meeting';
    db.query(sql,(err,result)=>{
        if(err){
        console.error('Error in fetching the meeting',err);
        res.status(500).json({error:'An error occured'});
    }else{
        res.status(200).json(result);
    }
    
    
    });
    });

//to get all clients

app.get('/getClients',(req,res)=>{
    const sql='select * from client1';
    db.query(sql,(err,result)=>{
        if(err){
        console.error('Error in fetching the client',err);
        res.status(500).json({error:'An error occured'});
    }else{
        res.status(200).json(result);
    }
    
    
    });
    });

    //to get a meeting on id
    app.get('/getMeeting/:id',(req,res)=>{
        const id=req.params.id;
        const sql='select * from meeting where meetingid=?';
        db.query(sql,[id],(err,result)=>{
            if(err){
            console.error('Error in fetching the meeting',err);
            res.status(500).json({error:'An error occured'});
        }else{
            res.status(200).json(result);
        }
       
        });
        });
    //to insert client into db
    app.post('/addClient',(req,res)=>{
        const {name1,email,address,password1,repeatpassword}=req.body;
        const sql='insert into client1 values(?,?,?,?,?)';
        db.query(sql,[name1,email,address,password1,repeatpassword],(err,result)=>{
            if(err){
                console.error('Error in adding the client',err);
                res.status(500).json({error:'An error occured'});
            }else{
                res.status(200).json({message:'Client added successfully'});
            }
    
    
        });
        });
      //to insert meeting into db
        app.post('/addMeeting',(req,res)=>{
            const {meetingid,meetingtopic,numberofpeople,starttime}=req.body;
            const sql='insert into meeting values(?,?,?,?)';
            db.query(sql,[meetingid,meetingtopic,numberofpeople,starttime],(err,result)=>{
                if(err){
                    console.error('Error in adding the meeting',err);
                    res.status(500).json({error:'An error occured'});
                }else{
                    res.status(200).json({message:'Meeting added successfully'});
                }
        
        
            });
            });

    //updation of meeting
    app.put('/updateMeeting',(req,res)=>{
        const {meetingid,meetingtopic,numberofpeople,starttime}=req.body;
        const sql='update meeting set meetingtopic=?,numberofpeople=?,starttime=? where meetingid=?';
        db.query(sql,[meetingtopic,numberofpeople,starttime,meetingid],(err,result)=>{
            if(err){
                console.error('Error in updating the meeting',err);
                res.status(500).json({error:'An error occured'});
            }else{
                res.status(200).json({message:'Meeting updated successfully'});
            }
    
    
        });
        });
    //cancel of meeting
    app.delete('/cancelMeeting/:meetingid',(req,res)=>{
        const id=req.params.meetingid;
        const sql='delete from meeting where meetingid=?';
        db.query(sql,[id],(err,result)=>{
            if(err){
            console.error('Error in cancelling the meeting',err);
            res.status(500).json({error:'An error occured'});
        }else{
            res.status(200).json({message:'Meeting cancelled successfully'});
        }
       
        });
        });
    
