package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class AddMeetingPage {

	private WebDriver driver;
	
	public AddMeetingPage() {
		
	    System.setProperty("webdriver.chrome.driver", "C:\\Users\\Abhra\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
	    driver=new ChromeDriver();//wd ->this object controlls all the ui components on the browser
	    
	}
	
	public void navigateTo() {
		driver.get("http://localhost:4200/add1");
	}
	
	
	public void enterMeetingdetails() {
		driver.findElement(By.name("meetingtopic")).sendKeys("troy");
		driver.findElement(By.name("meetingid")).sendKeys("17");
		driver.findElement(By.name("numberofpeople")).sendKeys("10");
		driver.findElement(By.name("starttime")).sendKeys("2023-08-31 22:52:00");
		driver.findElement(By.name("add")).click();
	}
	
	
	public String ismeetingAdded() {
	return	driver.findElement(By.name("h2")).getText();
	}
	
	public void closeBrowser() {
		driver.quit();
	}
}
