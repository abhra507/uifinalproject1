package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class AddClientPage {

	private WebDriver driver;
	
	public AddClientPage() {
		
	    System.setProperty("webdriver.chrome.driver", "C:\\Users\\Abhra\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
	    driver=new ChromeDriver();//wd ->this object controlls all the ui components on the browser
	    
	}
	
	public void navigateTo() {
		driver.get("http://localhost:4200/add");
	}
	
	
	public void enterClientdetails() {
		driver.findElement(By.name("name1")).sendKeys("sishu");
		driver.findElement(By.name("email")).sendKeys("s@gmail.com");
		driver.findElement(By.name("address")).sendKeys("kolkata");
		driver.findElement(By.name("password1")).sendKeys("abc");
		driver.findElement(By.name("repeatpassword")).sendKeys("abc");
		driver.findElement(By.name("add")).click();
	}
	
	
	public String iclientAdded() {
	return	driver.findElement(By.name("h1")).getText();
	}
	
	public void closeBrowser() {
		driver.quit();
	}
	
}
