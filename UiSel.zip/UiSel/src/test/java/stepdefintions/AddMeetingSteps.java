package stepdefintions;

import static org.junit.Assert.assertEquals;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.AddClientPage;
import pages.AddMeetingPage;

public class AddMeetingSteps {
private AddMeetingPage addMeetingpage=new AddMeetingPage();
private AddClientPage addClientpage=new AddClientPage();
	@Given("the user is on the add meeting page")
	public void navigateTomeetingPage() {
		addMeetingpage.navigateTo();
	}
    @When("the user enters meeting details and click on the add button")
    public void enterMeetingDetails() {
    	addMeetingpage.enterMeetingdetails();
    }
    @Then("the Meeting added successfully message should be the output on the page")
	public void addedSucccessfully1() {
    	assertEquals("Meeting added successfully",addMeetingpage.ismeetingAdded());
    	addMeetingpage.closeBrowser();
    }
    @Given("the user is on the add client page")
	public void navigateToclientPage() {
		addClientpage.navigateTo();
	}
    @When("the user enters client details and click on the add button")
    public void enterclientDetails() {
    	addClientpage.enterClientdetails();
    }
    @Then("the client added successfully message should be the output on the page")
	public void addedSucccessfully() {
    	assertEquals("Client added successfully",addClientpage.iclientAdded());
    	addClientpage.closeBrowser();
    }  
    
    
    
}
